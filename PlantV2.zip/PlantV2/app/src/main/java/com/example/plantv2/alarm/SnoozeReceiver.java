package com.example.plantv2.alarm;

public class SnoozeReceiver {
}
